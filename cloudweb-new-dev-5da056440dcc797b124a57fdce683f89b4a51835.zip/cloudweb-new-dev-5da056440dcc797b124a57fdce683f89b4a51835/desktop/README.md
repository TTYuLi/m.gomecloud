 安装 Node v7.8 (http://nodejs.org)
 `npm install`

开发:
 `npm run start`
 `http://localhost:8080/`

部署:
./deploy.sh
 nginx 配置请参考 nginx.conf
 
