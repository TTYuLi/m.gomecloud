
var funHigt = $('.function-introduction').offset().top - 80;
var applyHigt = $('.apply-scene').offset().top - 80;
var faqHigt = $('.faq').offset().top - 80;

$('.c-m-b-li').click(function() {
	var _index=$(this).index();
	if(_index === 0) {
		$('html, body').stop().animate({scrollTop: 400},100);
	} else if (_index === 1) {
		$('html, body').stop().animate({scrollTop: funHigt},100);
	} else if (_index === 2) {
		$('html, body').stop().animate({scrollTop: applyHigt},100);
	} else if (_index === 3) {
		$('html, body').stop().animate({scrollTop: faqHigt},100);
	}
});


$(function() {
	// 检测滚动条位置
	window.onscroll = function () {
        var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop; // 兼容ie
			 			 		// 向上箭头
				if (scrollTop > 400 ) {
					$('.back').css('display','block')
	  		}else {
					$('.back').css('display','none')
  			}
				
				if (scrollTop >= 354) {
            $('.cloud-head').attr('class', 'cloud-head c-fixed');
            $('.cloud-product-menu').css('display', 'block');
            
            $('.cloud-menu-box li:eq(0)').attr('class', 'c-m-b-li c-m-b-active').siblings().attr('class', 'c-m-b-li');
        } else {
            $('.cloud-product-menu').css('display', 'none');
           
            $('.cloud-head').attr('class', 'cloud-head');
            $('.cloud-menu-box li:eq(0)').attr('class', 'c-m-b-li').siblings().attr('class', 'c-m-b-li');
        }
        if (scrollTop >= funHigt - 100) {
        	$('.cloud-menu-box li:eq(1)').attr('class', 'c-m-b-li c-m-b-active').siblings().attr('class', 'c-m-b-li');
        } 
        if(scrollTop >= applyHigt - 100) {
        	$('.cloud-menu-box li:eq(2)').attr('class', 'c-m-b-li c-m-b-active').siblings().attr('class', 'c-m-b-li');
        } 
        if(scrollTop >= faqHigt - 300) {
        	$('.cloud-menu-box li:eq(3)').attr('class', 'c-m-b-li c-m-b-active').siblings().attr('class', 'c-m-b-li');
        }
    }
    
    // 应用场景 交互效果
	$('.apply-tab li').click(function() {
		var _index=$(this).index();
		if(_index === 0) {
			$(this).attr('class', 'apply-tab-li a-tab-active-0').siblings().attr('class', 'apply-tab-li');
		} else if(_index ===1||_index===2) {
			$(this).attr('class', 'apply-tab-li a-tab-active-1').siblings().attr('class', 'apply-tab-li');
		} else {
			$(this).attr('class', 'apply-tab-li a-tab-active-2').siblings().attr('class', 'apply-tab-li');
		}
		$('.apply-tab-content > div').eq(_index).css('display', 'block').siblings().css('display', 'none');
	});

	 

	// 控制导航栏显示
	$(".cloud-product-menu").mouseover(function(){
	 
		$('.cloud-nav-menu').css('display', 'block');
	})

	$(".cloud-product-menu").mouseout(function() {
	 
		$('.cloud-nav-menu').css('display', 'none');
	})
	 
})

