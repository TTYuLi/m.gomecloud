$(function(){
  var funHigt = $('.function-introduction').offset().top - 80;
  var applyHigt = $('.apply-scene').offset().top - 80;
  var faqHigt = $('.faq').offset().top - 80;
  
  
  
  $('.c-m-b-li').click(function() {
    var _index=$(this).index();
    if(_index === 0) {  
      $('html, body').stop().animate({scrollTop: 550},100);
    } else if (_index === 1) {
      $('html, body').stop().animate({scrollTop: funHigt},100);
    } else if (_index === 2) {
      $('html, body').stop().animate({scrollTop: applyHigt},100);
    } else if (_index === 3) {
      $('html, body').stop().animate({scrollTop: faqHigt},100);
     
    }
  });
  
   
  // 检测滚动条位置
  window.onscroll = function () {
    var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop; // 兼容ie
    // console.log(scrollTop);
    // console.log(applyHigt);

    			 		// 向上箭头
				if (scrollTop > 400 ) {
					$('.back').css('display','block')
	  		}else {
					$('.back').css('display','none')
  			}
    var ss = document.getElementById('apply-scene').offsetTop;
    // console.log(document.getElementById('apply-scene').offsetTop);
    // console.log(faqHigt);

    if (scrollTop >= 500) {
      $('.cloud-head').attr('class', 'cloud-head c-fixed');
      $('.cloud-product-menu').css('display', 'block');
      // $('.cloud-btn').css('display', 'block');
      $('.cloud-menu-box li:eq(0)').attr('class', 'c-m-b-li c-m-b-active').siblings().attr('class', 'c-m-b-li');
    } else {
      $('.cloud-product-menu').css('display', 'none');
      // $('.cloud-btn').css('display', 'none');
      $('.cloud-head').attr('class', 'cloud-head');
      $('.cloud-menu-box li:eq(0)').attr('class', 'c-m-b-li').siblings().attr('class', 'c-m-b-li');
    }
    if (scrollTop >= funHigt - 100) {
      $('.cloud-menu-box li:eq(1)').attr('class', 'c-m-b-li c-m-b-active').siblings().attr('class', 'c-m-b-li');
    } 
    if(scrollTop >= applyHigt - 100) {
      $('.cloud-menu-box li:eq(2)').attr('class', 'c-m-b-li c-m-b-active').siblings().attr('class', 'c-m-b-li');
    } 
    if(scrollTop >= faqHigt - 500) {
      $('.cloud-menu-box li:eq(3)').attr('class', 'c-m-b-li c-m-b-active').siblings().attr('class', 'c-m-b-li');
    }
  }
  
  
  $('.up-cloud-tab li').click(function() {
    var _index=$(this).index();
    $(this).attr('class', 'up-cloud-tab-li up-cloud-tab-active').siblings().attr('class', 'up-cloud-tab-li');
    $('.up-cloud-content > div').eq(_index).css('display', 'block').siblings().css('display', 'none');
  });
  
})
