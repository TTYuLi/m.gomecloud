// tab栏切换
$(function(){
  $('.btn span').click(function(){
    $(this).addClass('active').siblings().removeClass('active')
    var index = $(this).index()
    // console.log(index)
    $('.apply-info').eq(index).addClass('current').removeClass('hide').siblings().removeClass('current').addClass('hide')
  })
  
  $('.security-btn span').click(function(){
    $(this).addClass('security-active').siblings().removeClass('security-active')
    var index = $(this).index()
    // console.log(index)
    $('.apply-info').eq(index).addClass('current').removeClass('hide').siblings().removeClass('current').addClass('hide')
  })
})


	// 安全组动态

$(function(){
  var _hash = window.location.hash;
 
  var index = _hash.slice(1)
  
  $('.security-btn span').eq(index).addClass('security-active').siblings().removeClass('security-active')
 
  $('.apply-info').eq(index).addClass('current').removeClass('hide').siblings().removeClass('current').addClass('hide')

  $('.safe-action dd').click(function(evt){
    // console.log(evt);
    var _hash = evt.target.hash || window.evt.target.hash;
    // console.log(_hash)
    var index = _hash.slice(1)
    // console.log(index)
    $('.security-btn span').eq(index).addClass('security-active').siblings().removeClass('security-active')
   
    $('.apply-info').eq(index).addClass('current').removeClass('hide').siblings().removeClass('current').addClass('hide')

    $('.gm-nav-menu').css('display', 'none');
  })
})

// 新增产品页的固定导航

$(function(){
  // 产品概述
  var piHeight =$('.product-introduction').length ? Math.floor($('.product-introduction').offset().top) - 50 :'';
  // 产品优势
  var paHeight = $('.product-advantage').length ? Math.floor($('.product-advantage').offset().top) - 50 : '';
  // 应用场景
  // var asHeight = $('.apply-scence').length ? $('.apply-scence').offset().top - 50 : 1989;
  var asHeight = $('.apply-scence').length ? Math.floor($('.apply-scence').offset().top) - 50 : 1989;
  // 常见问题
  var cpHeight = $('.common-problem').length ? Math.floor($('.common-problem').offset().top) - 50 : 10000;
  // console.log(piHeight, paHeight, asHeight, cpHeight);
  
  // 点击导航效果 
  $('.gm-navbar-menu li').click(function(){
    var _index=$(this).index();
    // $(this).addClass('gm-btn-active').siblings().removeClass('gm-btn-active')
    if(_index === 0) {
			$('html, body').stop().animate({scrollTop: piHeight},100);
	   } else if (_index === 1) {
			$('html, body').stop().animate({scrollTop: paHeight},100);
	   } else if (_index === 2) {
      $('html, body').stop().animate({scrollTop: asHeight},100);
     }else if (_index === 3) {
      $('html, body').stop().animate({scrollTop: cpHeight},100);
     }
  })
  	// 检测滚动条位置
	window.onscroll = function () {
		var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop; // 兼容ie
    // console.log(scrollTop);
    			 		// 向上箭头
				if (scrollTop > 400 ) {
					$('.back').css('display','block')
	  		}else {
					$('.back').css('display','none')
  			}
      if (scrollTop >= 336) {
        /**
         * 显示白色tab选项
         */
        $('.gm-navbar').css({'display':'block'})
      } else {
        /**
         * 隐藏白色tab选项
         */
        $('.gm-navbar').css({'display': 'none'})
      }

      if ( scrollTop >= piHeight && scrollTop < paHeight ) {
        $('.gm-btn1').addClass('gm-btn-active').siblings().removeClass('gm-btn-active')

      } else if ( scrollTop >= paHeight -100 && scrollTop < asHeight - 100 ) {
        $('.gm-btn2').addClass('gm-btn-active').siblings().removeClass('gm-btn-active')

      }else if ( scrollTop >= asHeight - 100 && scrollTop < cpHeight) {
        $('.gm-btn3').addClass('gm-btn-active').siblings().removeClass('gm-btn-active')

      }else if ( scrollTop >= cpHeight - 100 ) {
        $('.gm-btn4').addClass('gm-btn-active').siblings().removeClass('gm-btn-active')

      }
		 
  }
 

  // 控制导航栏显示
	$(".gm-all-product").mouseover(function(){
		// console.log(1)
		$('.cloud-nav-menu').css('display', 'block');
	})

	$(".gm-all-product").mouseout(function() {
		// console.log(2)
		$('.cloud-nav-menu').css('display', 'none');
	})
})