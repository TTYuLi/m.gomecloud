
$(function() {
	var timer = null;
	$(".gm-nav-left .left-item:eq(0)").mouseover(function(){
		clearTimeout(timer);
		// console.log(10)
		$(".gm-nav-left > div:eq(0)").css('color', '#1dc3ed');
		$('.gm-nav-menu').css('display', 'block');
	})

	$(".gm-nav-left > div:eq(0)").mouseout(function() {
		timer = setTimeout(function() {
			// console.log(20)
			$(".gm-nav-left > div:eq(0)").css('color', 'white');
			$('.gm-nav-menu').css('display', 'none');
		},200);
	})

	// 导航字体颜色悬停变化
	$(".col a").mouseover(function(){
		$(this).css('color', '#0d98ce');
	})
	$(".col a").mouseout(function(){
		$(this).css('color', '#000');
	})

	// 翻页显示向上按钮
	window.onscroll = function () {
		var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;		
		 if (scrollTop > 400 ) {
				 $('.back').css('display','block')
		 }else {
				 $('.back').css('display','none')
		 }
	}


	  // 鼠标悬停二维码显示
		$('.f-wx').mouseover(function(){
			$('.f-wxcode').css({'display':'block'})
	}).mouseout(function(){
			$('.f-wxcode').css({'display':'none'})
	})
})

function pageScrollTop() {
    var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
    if (scrollTop !== 0){
        window.scrollBy(0,-100);
        scrolldelay = setTimeout('pageScrollTop()',20);
    }
}
function pageScrollBottom() {
	var yScroll = document.body.clientHeight || document.documentElement.scrollHeight; 
  window.scrollBy(0,yScroll);
}

function getExplorerInfo() {
	var explorer = window.navigator.userAgent.toLowerCase() ;
	//ie 
	if (explorer.indexOf("msie") >= 0) {
		var ver=explorer.match(/msie ([\d.]+)/)[1];
		return {type:"IE",version:ver};
	}
	//firefox 
	else if (explorer.indexOf("firefox") >= 0) {
		var ver=explorer.match(/firefox\/([\d.]+)/)[1];
		return {type:"Firefox",version:ver};
	}
	//Chrome
	else if(explorer.indexOf("chrome") >= 0){
		var ver=explorer.match(/chrome\/([\d.]+)/)[1];
		return {type:"Chrome",version:ver};
	}
	//Opera
	else if(explorer.indexOf("opera") >= 0){
		var ver=explorer.match(/opera.([\d.]+)/)[1];
		return {type:"Opera",version:ver};
	}
	//Safari
	else if(explorer.indexOf("Safari") >= 0){
		var ver=explorer.match(/version\/([\d.]+)/)[1];
		return {type:"Safari",version:ver};
	}
  else {
    return {type:"",version:''}
  }
}
 var types = getExplorerInfo().type;
 var version = getExplorerInfo().version;
 if(types === 'IE') {
 	if(version === '8.0' || version === '7.0' || version === '6.0') {
 		alert("浏览器版本过低，请到指定网站去下载相关版本"); 
 		window.open("http://outdatedbrowser.com/zh-cn");  
 	}
 }